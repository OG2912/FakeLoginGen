# FakeLoginGen

## 🎭 Fake Login Page Generator (Phishing Simulator)

This tool generates fake login pages for platforms like Facebook and logs the credentials submitted.

### ⚙️ Requirements

```bash
pip install flask
```

### 🚀 Usage

```bash
python3 app.py
```

Access the pages:
- http://localhost:5000/facebook

### 📁 Logs

Submitted credentials are saved in `logs/credentials.txt`.

### ⚠️ Disclaimer

- 🧠 For educational purposes and phishing awareness training only.
- 🚫 DO NOT use this for real phishing or illegal activity.
